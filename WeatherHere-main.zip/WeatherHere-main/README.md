# WeatherHere_iOS_Application
WeatherHere fetches the temperature of the current location and user can search for the temperature of other city. Used OpenWeatherMap API to fetch the temperature. This application is designed for both light and dark theme.This application is made by using MVC design architecture pattern
![Simulator Screen Shot - iPhone 12 mini - 2022-07-05 at 01 48 33](https://user-images.githubusercontent.com/81093987/177213308-f082e066-586e-4a85-ac7e-7e6f0379f17d.png)
![Simulator Screen Shot - iPhone 12 mini - 2022-07-05 at 01 51 16](https://user-images.githubusercontent.com/81093987/177213312-7138ab06-3212-43e2-a38d-54cc17952006.png)
